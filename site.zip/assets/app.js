(function () {
  'use strict';
  var S = window.SITE || {};
  var $ = function (id) { return document.getElementById(id); };
  function ph(v) { return v == null || v === '' || /\[|VOTRE-|VOTRE_|votre-domaine|exemple\./.test(String(v)); }
  function ok(v) { return !ph(v); }

  if (ok(S.rue) && ok(S.codePostal) && ok(S.ville)) S.adresse = S.rue + ', ' + S.codePostal + ' ' + S.ville;

  /* ---------- Filet de sécurité : adresses canoniques recalées sur le vrai domaine tant que le placeholder est présent ---------- */
  var PH_DOMAIN = 'https://www.votre-domaine.fr';
  document.querySelectorAll('link[rel="canonical"],meta[property="og:url"],meta[property="og:image"]').forEach(function (el) {
    var attr = el.tagName === 'LINK' ? 'href' : 'content', v = el.getAttribute(attr);
    if (v && v.indexOf(PH_DOMAIN) === 0) el.setAttribute(attr, location.origin + v.slice(PH_DOMAIN.length));
  });

  /* ---------- Menu mobile ---------- */
  var burger = $('burger'), menu = $('menu');
  if (burger && menu) {
    burger.addEventListener('click', function () {
      var o = menu.classList.toggle('open');
      burger.setAttribute('aria-expanded', o);
    });
    menu.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') { menu.classList.remove('open'); burger.setAttribute('aria-expanded', false); }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && menu.classList.contains('open')) { menu.classList.remove('open'); burger.setAttribute('aria-expanded', false); burger.focus(); }
    });
  }

  /* ---------- Informations de config.js injectées dans les pages ---------- */
  document.querySelectorAll('[data-cfg]').forEach(function (el) {
    var v = S[el.getAttribute('data-cfg')];
    if (v != null && v !== '' && typeof v !== 'object') el.textContent = v;
  });
  document.querySelectorAll('[data-href-tel]').forEach(function (el) {
    var v = S[el.getAttribute('data-href-tel')];
    if (ok(v)) el.setAttribute('href', 'tel:' + String(v).replace(/[^\d+]/g, ''));
  });
  document.querySelectorAll('[data-href-mail]').forEach(function (el) {
    var v = S[el.getAttribute('data-href-mail')];
    if (ok(v)) el.setAttribute('href', 'mailto:' + v);
  });
  document.querySelectorAll('[data-href]').forEach(function (el) {
    var v = S[el.getAttribute('data-href')];
    if (ok(v)) el.setAttribute('href', v);
  });
  document.querySelectorAll('[data-needs]').forEach(function (el) {
    var keys = el.getAttribute('data-needs').split(' ');
    if (keys.every(function (k) { return ok(S[k]); })) el.hidden = false;
  });

  document.querySelectorAll('[data-if-google-fonts]').forEach(function (el) { el.hidden = (S.policesGoogle === false); });

  /* ---------- Avis clients (uniquement ceux saisis dans config.js) ---------- */
  var rv = $('reviews');
  if (rv) {
    var list = (S.avis || []).filter(function (a) { return a && a.texte && a.auteur; });
    if (list.length) {
      list.forEach(function (a) {
        var n = Math.max(1, Math.min(5, parseInt(a.note, 10) || 5));
        var f = document.createElement('figure'); f.className = 'review';
        var st = document.createElement('div'); st.className = 'stars'; st.setAttribute('aria-hidden', 'true');
        st.textContent = '★★★★★'.slice(0, n) + '☆☆☆☆☆'.slice(0, 5 - n);
        var sr = document.createElement('span'); sr.className = 'sr'; sr.textContent = 'Note : ' + n + ' sur 5';
        var q = document.createElement('blockquote'); q.textContent = a.texte;
        var c = document.createElement('figcaption'); c.textContent = a.auteur + (a.ville ? ', ' + a.ville : '');
        f.appendChild(st); f.appendChild(sr); f.appendChild(q); f.appendChild(c); rv.appendChild(f);
      });
      rv.hidden = false;
      var em = $('reviews-empty'); if (em) em.hidden = true;
    }
  }

  /* ---------- Données structurées Google (uniquement si les vraies infos sont renseignées) ---------- */
  if (document.body.hasAttribute('data-jsonld') && ok(S.nom) && ok(S.telephone) && ok(S.email) && ok(S.rue) && ok(S.codePostal) && ok(S.ville)) {
    var ld = {
      '@context': 'https://schema.org', '@type': 'Plumber',
      name: S.nom, url: location.origin + '/', telephone: S.telephone, email: S.email,
      image: location.origin + '/assets/img/og-image.jpg',
      address: { '@type': 'PostalAddress', streetAddress: S.rue, postalCode: S.codePostal, addressLocality: S.ville, addressCountry: 'FR' }
    };
    if (ok(S.zone)) ld.areaServed = S.zone;
    if (S.ouverture && S.ouverture.jours) {
      ld.openingHoursSpecification = [{ '@type': 'OpeningHoursSpecification', dayOfWeek: S.ouverture.jours.map(function (d) { return { Mo: 'Monday', Tu: 'Tuesday', We: 'Wednesday', Th: 'Thursday', Fr: 'Friday', Sa: 'Saturday', Su: 'Sunday' }[d]; }), opens: S.ouverture.de, closes: S.ouverture.a }];
    }
    var sc = document.createElement('script'); sc.type = 'application/ld+json'; sc.textContent = JSON.stringify(ld);
    document.head.appendChild(sc);
  }

  /* ---------- Petit message d'information ---------- */
  var toastEl, toastT;
  function toast(msg) {
    if (!toastEl) {
      toastEl = document.createElement('div'); toastEl.className = 'toast';
      toastEl.setAttribute('role', 'status'); toastEl.hidden = true; document.body.appendChild(toastEl);
    }
    toastEl.textContent = msg; toastEl.hidden = false;
    clearTimeout(toastT); toastT = setTimeout(function () { toastEl.hidden = true; }, 4500);
  }

  /* ---------- Réservation Calendly : chargé uniquement au clic (RGPD + vitesse) ---------- */
  var calState = 'idle', calQueue = [];
  function loadCalendly(onReady, onFail) {
    if (window.Calendly && typeof window.Calendly.initPopupWidget === 'function') { onReady(); return; }
    if (calState === 'failed') { onFail(); return; }
    calQueue.push({ ok: onReady, ko: onFail });
    if (calState === 'loading') return;
    calState = 'loading';
    var done = false;
    function end(good) {
      if (done) return; done = true; clearTimeout(timer);
      calState = good ? 'ready' : 'failed';
      calQueue.splice(0).forEach(function (q) { good ? q.ok() : q.ko(); });
    }
    var timer = setTimeout(function () { end(false); }, 7000);
    var l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'https://assets.calendly.com/assets/external/widget.css'; document.head.appendChild(l);
    var s = document.createElement('script'); s.src = 'https://assets.calendly.com/assets/external/widget.js'; s.async = true;
    s.onload = function () { end(!!(window.Calendly && typeof window.Calendly.initPopupWidget === 'function')); };
    s.onerror = function () { end(false); };
    document.head.appendChild(s);
  }
  function fallbackOpen(url) {
    var w = window.open(url, '_blank');
    if (w) { try { w.opener = null; } catch (e) {} } else { location.href = url; }
  }
  function openBooking(key, btn) {
    var url = (S.calendly || {})[key] || (S.calendly || {}).tous;
    if (!ok(url)) { toast('La réservation en ligne sera bientôt disponible. Utilisez le formulaire de contact en attendant.'); return; }
    if (btn) { btn.classList.add('is-loading'); btn.setAttribute('aria-busy', 'true'); }
    function free() { if (btn) { btn.classList.remove('is-loading'); btn.removeAttribute('aria-busy'); } }
    loadCalendly(function () {
      free();
      var opts = { url: url };
      if (window.VP_PREFILL) opts.prefill = window.VP_PREFILL;
      window.Calendly.initPopupWidget(opts);
    }, function () { free(); fallbackOpen(url); });
  }
  document.querySelectorAll('[data-calendly]').forEach(function (el) {
    var url = (S.calendly || {})[el.getAttribute('data-calendly')] || (S.calendly || {}).tous;
    if (ok(url)) el.setAttribute('href', url);
    el.addEventListener('click', function (e) { e.preventDefault(); openBooking(el.getAttribute('data-calendly'), el); });
    var warm = function () { loadCalendly(function () {}, function () {}); };
    ['pointerenter', 'touchstart', 'focus'].forEach(function (ev) {
      el.addEventListener(ev, function once() { if (ok(url)) warm(); el.removeEventListener(ev, once); }, { passive: true });
    });
  });

  /* ---------- Formulaire de contact (Formspree, sans backend) ---------- */
  var cf = $('contact-form');
  if (cf) {
    var cs = $('f-status'), cb = $('f-submit'), t0 = Date.now(), lastSent = 0;
    cf.addEventListener('submit', function (e) {
      e.preventDefault();
      cs.className = 'status';
      if (!cf.checkValidity()) { cs.textContent = 'Merci de remplir tous les champs et d’accepter le traitement de vos données.'; cs.className = 'status err'; cf.reportValidity(); return; }
      var hp = cf.querySelector('[name="_gotcha"]');
      if ((hp && hp.value) || Date.now() - t0 < 1500) { cs.textContent = 'Merci, votre message a bien été envoyé.'; cs.className = 'status ok'; return; } /* anti-robot : on fait semblant */
      if (Date.now() - lastSent < 20000) { cs.textContent = 'Votre message vient d’être envoyé. Patientez quelques secondes avant d’en envoyer un autre.'; cs.className = 'status err'; return; }
      if (!ok(S.formspree)) { cs.textContent = 'Le formulaire n’est pas encore configuré. Écrivez-nous directement par e-mail.'; cs.className = 'status err'; return; }
      cb.disabled = true; cs.textContent = 'Envoi en cours…';
      fetch(S.formspree, { method: 'POST', body: new FormData(cf), headers: { Accept: 'application/json' } })
        .then(function (r) { if (!r.ok) throw new Error(); lastSent = Date.now(); cf.reset(); cs.textContent = 'Merci, votre message a bien été envoyé. Nous vous répondons rapidement.'; cs.className = 'status ok'; })
        .catch(function () { cs.textContent = 'L’envoi a échoué. Réessayez ou écrivez-nous par e-mail.'; cs.className = 'status err'; })
        .then(function () { cb.disabled = false; });
    });
  }

  /* ---------- Aide à la mise en ligne : liste dans la console ce qu'il reste à renseigner ---------- */
  var missing = ['telephone', 'email', 'rue', 'codePostal', 'ville', 'siret', 'directeurPublication', 'hebergeur', 'assurance', 'tva', 'mediateur', 'conservation', 'zone', 'delai', 'annulation', 'formspree']
    .filter(function (k) { return !ok(S[k]); });
  ['tous', 'domicile', 'diagnostic', 'guidee'].forEach(function (k) { if (!ok((S.calendly || {})[k])) missing.push('calendly.' + k); });
  if (missing.length && window.console) console.info('[Votre plombier] Configuration incomplète dans assets/config.js :', missing.join(', '));
})();
