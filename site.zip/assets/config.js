/* =====================================================================
   CONFIGURATION DU SITE : c'est le SEUL fichier à modifier.
   Les valeurs entre crochets [ ... ] sont celles qu'il reste à renseigner :
   tant qu'elles restent entre crochets, elles apparaissent telles quelles sur le site.
   ===================================================================== */
window.SITE = {

  /* --- Votre entreprise --- */
  nom: "Votre plombier Essonne",                    // nom affiché sur le site (logo, pied de page, Google)
  signature: "SL Pro IDF",                          // affiché en petit sous le logo : « by SL Pro IDF »
  editeur: "Stéphane LABONNE, entrepreneur individuel (EI), nom commercial : SL Pro IDF",   // identité légale (mentions légales, CGV)
  telephone: "07 80 23 54 56",
  email: "slproidf@gmail.com",
  rue: "225 route de Corbeil",
  codePostal: "91700",
  ville: "Sainte-Geneviève-des-Bois",
  adresse: "225 route de Corbeil, 91700 Sainte-Geneviève-des-Bois",   // recomposée automatiquement avec rue + code postal + ville
  siret: "979 789 278 00012",
  directeurPublication: "Stéphane LABONNE",
  hebergeur: "GitHub, Inc., 88 Colin P. Kelly Jr. Street, San Francisco, CA 94107, États-Unis (GitHub Pages)",
  assurance: "[Assureur et numéro de contrat (responsabilité civile professionnelle / décennale)]",
  tva: "[TVA non applicable, art. 293 B du CGI]",   // ou : "TVA incluse"
  mediateur: "[Nom, adresse postale et site web du médiateur de la consommation]",
  conservation: "3 ans",                             // durée de conservation des données

  /* --- Informations affichées dans la FAQ et la page À propos --- */
  horaires: "Du lundi au samedi",
  ouverture: null,   // pour afficher vos heures sur Google : { jours: ["Mo","Tu","We","Th","Fr","Sa"], de: "08:00", a: "19:00" }
  zone: "Essonne (91)",
  delai: "[Délai moyen d’intervention, par exemple : sous 24 à 48 h, plus rapidement en cas d’urgence]",
  annulation: "[Politique d’annulation, par exemple : annulation ou report gratuit jusqu’à 24 h avant le rendez-vous]",

  /* --- Réservation en ligne (Calendly) --- */
  calendly: {
    tous:       "https://calendly.com/VOTRE-COMPTE",                      // page listant toutes les prestations
    domicile:   "https://calendly.com/VOTRE-COMPTE/intervention-domicile", // sur place
    diagnostic: "https://calendly.com/VOTRE-COMPTE/diagnostic-express",    // à distance, 30 € (paiement Stripe obligatoire)
    guidee:     "https://calendly.com/VOTRE-COMPTE/reparation-guidee"      // à distance, 45 € (paiement Stripe obligatoire)
  },

  /* --- Formulaire de contact (Formspree) --- */
  formspree: "https://formspree.io/f/VOTRE_ID",

  /* --- Comptes clients et messagerie (Supabase). Vide = mode démonstration --- */
  supabase: { url: "", anonKey: "" },

  /* --- Avis clients : ajoutez UNIQUEMENT de vrais avis, avec l'accord du client ---
     Exemple : { note: 5, texte: "Intervention rapide et soignée.", auteur: "Marie D.", ville: "Évry" }  */
  avis: [],
  avisGoogle: "[Lien de votre page d’avis Google]",

  /* --- Polices : true = Google Fonts (police identique à la maquette), false = aucune requête vers Google --- */
  policesGoogle: true
};

/* ---------- Ne rien modifier sous cette ligne ---------- */
(function () {
  var S = window.SITE;
  if (S.policesGoogle !== false) {
    var h = document.head, l;
    l = document.createElement('link'); l.rel = 'preconnect'; l.href = 'https://fonts.googleapis.com'; h.appendChild(l);
    l = document.createElement('link'); l.rel = 'preconnect'; l.href = 'https://fonts.gstatic.com'; l.crossOrigin = ''; h.appendChild(l);
    l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap'; h.appendChild(l);
  }
})();
