/* =====================================================================
   CONFIGURATION DU SITE : c'est le SEUL fichier à modifier.
   Remplacez chaque valeur entre crochets [ ... ] par vos vraies informations.
   Tant qu'une valeur reste entre crochets, elle apparaît telle quelle sur le site.
   ===================================================================== */
window.SITE = {

  /* --- Votre entreprise --- */
  nom: "Votre plombier",
  telephone: "[01 23 45 67 89]",
  email: "[contact@votre-domaine.fr]",
  rue: "[Numéro et rue]",
  codePostal: "[Code postal]",
  ville: "[Ville]",
  adresse: "[Adresse postale complète]",           // recomposée automatiquement avec rue + code postal + ville
  siret: "[Numéro SIRET]",
  directeurPublication: "[Nom et prénom]",
  hebergeur: "[Nom de l’hébergeur, adresse et téléphone]",
  assurance: "[Assureur et numéro de contrat (responsabilité civile professionnelle / décennale)]",
  tva: "[TVA non applicable, art. 293 B du CGI]",   // ou : "TVA incluse"
  mediateur: "[Nom, adresse postale et site web du médiateur de la consommation]",
  conservation: "[3 ans]",                           // durée de conservation des données

  /* --- Informations affichées dans la FAQ et la page À propos --- */
  horaires: "Du lundi au samedi",
  ouverture: { jours: ["Mo", "Tu", "We", "Th", "Fr", "Sa"], de: "08:00", a: "19:00" },   // utilisé par Google
  zone: "[Zone d’intervention : villes ou départements couverts]",
  delai: "[Délai moyen d’intervention, par exemple : sous 24 à 48 h, plus rapidement en cas d’urgence]",
  annulation: "[Politique d’annulation, par exemple : annulation ou report gratuit jusqu’à 24 h avant le rendez-vous]",

  /* --- Réservation en ligne (Calendly) --- */
  calendly: {
    tous:       "https://calendly.com/VOTRE-COMPTE",                      // page listant toutes les prestations
    domicile:   "https://calendly.com/VOTRE-COMPTE/intervention-domicile", // sur place
    diagnostic: "https://calendly.com/VOTRE-COMPTE/diagnostic-express",    // à distance, 30 € (paiement Stripe obligatoire)
    guidee:     "https://calendly.com/VOTRE-COMPTE/reparation-guidee"      // à distance, 45 € (paiement Stripe obligatoire)
  },

  /* --- Formulaire de contact (Formspree) --- */
  formspree: "https://formspree.io/f/VOTRE_ID",

  /* --- Comptes clients et messagerie (Supabase). Vide = mode démonstration --- */
  supabase: { url: "", anonKey: "" },

  /* --- Avis clients : ajoutez UNIQUEMENT de vrais avis, avec l'accord du client ---
     Exemple : { note: 5, texte: "Intervention rapide et soignée.", auteur: "Marie D.", ville: "Lyon" }  */
  avis: [],
  avisGoogle: "[Lien de votre page d’avis Google]",

  /* --- Polices : true = Google Fonts (police identique à la maquette), false = aucune requête vers Google --- */
  policesGoogle: true
};

/* ---------- Ne rien modifier sous cette ligne ---------- */
(function () {
  var S = window.SITE;
  if (S.policesGoogle !== false) {
    var h = document.head, l;
    l = document.createElement('link'); l.rel = 'preconnect'; l.href = 'https://fonts.googleapis.com'; h.appendChild(l);
    l = document.createElement('link'); l.rel = 'preconnect'; l.href = 'https://fonts.gstatic.com'; l.crossOrigin = ''; h.appendChild(l);
    l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap'; h.appendChild(l);
  }
})();
