(function () {
  'use strict';
  var S = window.SITE || {};
  var $ = function (id) { return document.getElementById(id); };
  var cfgSb = S.supabase || {};
  var hasSb = !!(cfgSb.url && cfgSb.anonKey);
  var cameFromEmail = /access_token|type=(signup|recovery|magiclink)/.test(location.hash);
  var cameFromRecovery = /type=recovery/.test(location.hash);
  var BASE_TITLE = document.title;
  var BUCKET = 'message-photos';
  var BLANK = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
  var SUPABASE_CDN = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js';

  function frErr(e) {
    var m = (e && e.message) || '';
    if (/Invalid login/i.test(m)) return 'E-mail ou mot de passe incorrect.';
    if (/already registered|already been registered/i.test(m)) return 'Un compte existe déjà avec cet e-mail.';
    if (/not confirmed/i.test(m)) return 'Confirmez d’abord votre adresse e-mail (lien reçu par message).';
    if (/Password should be/i.test(m)) return 'Mot de passe trop court (8 caractères minimum).';
    if (/rate limit/i.test(m)) return 'Trop de tentatives. Réessayez dans quelques minutes.';
    if (/row-level security|violates/i.test(m)) return 'Action non autorisée.';
    return m || 'Une erreur est survenue. Réessayez.';
  }
  function say(el, msg, kind) { el.textContent = msg; el.className = 'status' + (kind ? ' ' + kind : ''); }
  function loadScript(src) {
    return new Promise(function (res, rej) {
      var s = document.createElement('script'); s.src = src; s.onload = res;
      s.onerror = function () { rej(new Error('script')); }; document.head.appendChild(s);
    });
  }

  /* ---------- Compression des photos avant envoi ---------- */
  function compress(file, max, q) {
    return new Promise(function (res, rej) {
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        URL.revokeObjectURL(url);
        var r = Math.min(1, max / Math.max(img.width, img.height));
        var c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(img.width * r)); c.height = Math.max(1, Math.round(img.height * r));
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        c.toBlob(function (b) { b ? res(b) : rej(new Error('Image illisible.')); }, 'image/jpeg', q);
      };
      img.onerror = function () { URL.revokeObjectURL(url); rej(new Error('Ce format d’image n’est pas pris en charge. Essayez une photo JPEG ou PNG.')); };
      img.src = url;
    });
  }
  function blobToDataUrl(b) {
    return new Promise(function (res, rej) { var f = new FileReader(); f.onload = function () { res(f.result); }; f.onerror = function () { rej(new Error('Lecture impossible.')); }; f.readAsDataURL(b); });
  }

  /* ---------- Backend Supabase ---------- */
  var sb = null, urlCache = {};
  var Sb = {
    photoOpts: { max: 1600, q: 0.8 },
    session: async function () {
      var r = await sb.auth.getSession(); var s = r.data && r.data.session; if (!s) return null;
      var p = await sb.from('profiles').select('full_name,is_admin').eq('id', s.user.id).maybeSingle();
      var pr = p.data || {};
      return { id: s.user.id, email: s.user.email, name: pr.full_name || s.user.email, isAdmin: !!pr.is_admin };
    },
    signUp: async function (name, email, pwd) {
      var r = await sb.auth.signUp({ email: email, password: pwd, options: { data: { full_name: name }, emailRedirectTo: location.origin + location.pathname } });
      if (r.error) throw r.error; return { needsConfirm: !r.data.session };
    },
    signIn: async function (email, pwd) { var r = await sb.auth.signInWithPassword({ email: email, password: pwd }); if (r.error) throw r.error; },
    signOut: async function () { await sb.auth.signOut(); },
    reset: async function (email) { var r = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname }); if (r.error) throw r.error; },
    updatePassword: async function (pwd) { var r = await sb.auth.updateUser({ password: pwd }); if (r.error) throw r.error; },
    signed: async function (rows) {
      var need = [], now = Date.now();
      rows.forEach(function (r) { if (r.photo_path) { var c = urlCache[r.photo_path]; if (!c || c.exp < now + 60000) need.push(r.photo_path); } });
      if (need.length) {
        var r = await sb.storage.from(BUCKET).createSignedUrls(need, 3600);
        if (r.data) r.data.forEach(function (x) { if (x.signedUrl) urlCache[x.path] = { url: x.signedUrl, exp: now + 3600000 }; });
      }
      rows.forEach(function (r) { if (r.photo_path && urlCache[r.photo_path]) r.photo_url = urlCache[r.photo_path].url; });
      return rows;
    },
    messages: async function (cid) {
      var r = await sb.from('messages').select('id,from_pro,body,created_at,photo_path').eq('client_id', cid).order('created_at', { ascending: true });
      if (r.error) throw r.error; return Sb.signed(r.data || []);
    },
    send: async function (cid, body, fromPro, senderId, blob) {
      var path = null;
      if (blob) {
        path = cid + '/' + Date.now() + '-' + Math.random().toString(36).slice(2, 8) + '.jpg';
        var up = await sb.storage.from(BUCKET).upload(path, blob, { contentType: 'image/jpeg', upsert: false });
        if (up.error) throw up.error;
      }
      var r = await sb.from('messages').insert({ client_id: cid, sender_id: senderId, from_pro: fromPro, body: body || '', photo_path: path });
      if (r.error) { if (path) sb.storage.from(BUCKET).remove([path]); throw r.error; }
    },
    conversations: async function () {
      var m = await sb.from('messages').select('client_id,from_pro,body,photo_path,created_at').order('created_at', { ascending: false });
      if (m.error) throw m.error;
      var p = await sb.from('profiles').select('id,full_name,email');
      var names = {}; (p.data || []).forEach(function (x) { names[x.id] = x; });
      var seen = {}, out = [];
      (m.data || []).forEach(function (x) {
        if (seen[x.client_id]) return; seen[x.client_id] = 1;
        var pr = names[x.client_id] || {};
        out.push({ client_id: x.client_id, name: pr.full_name, email: pr.email, last: x.body ? String(x.body).slice(0, 60) : '📷 Photo', last_from_pro: !!x.from_pro, last_at: x.created_at });
      });
      return out;
    },
    deleteAccount: async function (uid) {
      try {
        var l = await sb.storage.from(BUCKET).list(uid, { limit: 1000 });
        if (l.data && l.data.length) await sb.storage.from(BUCKET).remove(l.data.map(function (x) { return uid + '/' + x.name; }));
      } catch (e) {}
      var r = await sb.rpc('delete_my_account'); if (r.error) throw r.error;
      try { await sb.auth.signOut(); } catch (e) {}
    }
  };

  /* ---------- Backend démonstration (localStorage, NON sécurisé, uniquement pour tester) ---------- */
  var Demo = (function () {
    function get(k) { try { return JSON.parse(localStorage.getItem(k)) || []; } catch (e) { return []; } }
    function set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
    async function hash(s) {
      if (window.crypto && window.crypto.subtle) {
        var b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
        return Array.from(new Uint8Array(b)).map(function (x) { return x.toString(16).padStart(2, '0'); }).join('');
      }
      return btoa(unescape(encodeURIComponent(s)));
    }
    function sid() { try { return localStorage.getItem('vp_session'); } catch (e) { return null; } }
    return {
      photoOpts: { max: 900, q: 0.6 },
      session: async function () {
        var id = sid(); if (!id) return null;
        var u = get('vp_users').filter(function (x) { return x.id === id; })[0]; if (!u) return null;
        return { id: u.id, email: u.email, name: u.name, isAdmin: false };
      },
      signUp: async function (name, email, pwd) {
        email = email.toLowerCase(); var users = get('vp_users');
        if (users.some(function (x) { return x.email === email; })) throw new Error('Un compte existe déjà avec cet e-mail.');
        var u = { id: 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), name: name, email: email, h: await hash(pwd) };
        users.push(u); set('vp_users', users); try { localStorage.setItem('vp_session', u.id); } catch (e) {}
        return { needsConfirm: false };
      },
      signIn: async function (email, pwd) {
        email = email.toLowerCase(); var h = await hash(pwd);
        var u = get('vp_users').filter(function (x) { return x.email === email && x.h === h; })[0];
        if (!u) throw new Error('E-mail ou mot de passe incorrect.');
        try { localStorage.setItem('vp_session', u.id); } catch (e) {}
      },
      signOut: async function () { try { localStorage.removeItem('vp_session'); } catch (e) {} },
      reset: async function () { throw new Error('Indisponible en mode démonstration.'); },
      updatePassword: async function () { throw new Error('Indisponible en mode démonstration.'); },
      messages: async function (cid) { return get('vp_msgs').filter(function (m) { return m.client_id === cid; }); },
      send: async function (cid, body, fromPro, senderId, blob) {
        var m = { id: Date.now() + Math.random(), client_id: cid, from_pro: fromPro, body: body || '', created_at: new Date().toISOString() };
        if (blob) m.photo_url = await blobToDataUrl(blob);
        var l = get('vp_msgs'); l.push(m);
        if (!set('vp_msgs', l)) throw new Error('Espace de stockage du navigateur plein : photo non envoyée.');
      },
      conversations: async function () { return []; },
      deleteAccount: async function (uid) {
        set('vp_users', get('vp_users').filter(function (u) { return u.id !== uid; }));
        set('vp_msgs', get('vp_msgs').filter(function (m) { return m.client_id !== uid; }));
        try { localStorage.removeItem('vp_session'); } catch (e) {}
      }
    };
  })();

  var Backend = null;

  /* ---------- Interface ---------- */
  var St = { user: null, client: null, timer: null, sig: '', convSig: '', photo: null, previewUrl: null };
  var authBox = $('auth-box'), dash = $('dash'), thread = $('thread'), msgForm = $('msg-form'), msgText = $('msg-text'),
      msgSubmit = $('msg-submit'), msgStatus = $('msg-status'), inbox = $('admin-inbox'), convList = $('conv-list'),
      messaging = $('messaging'), threadTitle = $('thread-title'), recBox = $('recovery-box'),
      fileInput = $('msg-photo'), photoPrev = $('photo-preview'), photoImg = $('photo-preview-img');

  function fmt(d) { try { return new Date(d).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; } }

  function renderThread(list) {
    var mineIsPro = !!(St.user && St.user.isAdmin);
    var last = list[list.length - 1];
    var sig = St.client + '|' + list.length + '|' + (last ? last.created_at + (last.photo_url ? 'p' : '') : '');
    if (sig === St.sig) return;
    var atBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 60;
    var firstRender = St.sig === '' || St.sig.indexOf(St.client + '|') !== 0;
    St.sig = sig;
    thread.textContent = '';
    if (!list.length) {
      var p = document.createElement('p'); p.className = 'empty';
      p.textContent = St.client ? 'Aucun message pour l’instant. Écrivez-nous ci-dessous, vous pouvez joindre une photo.' : 'Sélectionnez une conversation.';
      thread.appendChild(p); return;
    }
    list.forEach(function (m) {
      var d = document.createElement('div');
      d.className = 'msg ' + ((!!m.from_pro === mineIsPro) ? 'mine' : 'theirs');
      if (m.body) { var t = document.createElement('span'); t.textContent = m.body; d.appendChild(t); }
      if (m.photo_url) {
        var pb = document.createElement('button'); pb.type = 'button'; pb.className = 'photo-btn';
        pb.setAttribute('aria-label', 'Agrandir ou réduire la photo');
        var im = document.createElement('img'); im.src = m.photo_url; im.alt = 'Photo jointe au message'; im.loading = 'lazy';
        pb.appendChild(im); pb.addEventListener('click', function () { pb.classList.toggle('zoom'); }); d.appendChild(pb);
      } else if (m.photo_path) {
        var u = document.createElement('span'); u.textContent = '📷 Photo (chargement impossible)'; d.appendChild(u);
      }
      var ti = document.createElement('time'); ti.textContent = fmt(m.created_at); d.appendChild(ti);
      thread.appendChild(d);
    });
    if (firstRender || atBottom) thread.scrollTop = thread.scrollHeight;
  }
  async function loadThread() {
    if (!St.client) { renderThread([]); return; }
    try { renderThread(await Backend.messages(St.client)); } catch (e) {}
  }
  async function loadConvs() {
    try {
      var list = await Backend.conversations();
      var todo = list.filter(function (c) { return !c.last_from_pro; }).length;
      document.title = (todo ? '(' + todo + ') ' : '') + BASE_TITLE;
      var sig = JSON.stringify(list) + '|' + St.client;
      if (sig === St.convSig) return; St.convSig = sig;
      convList.textContent = '';
      if (!list.length) { var li = document.createElement('li'); li.className = 'empty'; li.textContent = 'Aucune conversation.'; convList.appendChild(li); return; }
      list.forEach(function (c) {
        var li = document.createElement('li'), b = document.createElement('button');
        b.type = 'button'; b.className = 'conv';
        if (c.client_id === St.client) b.setAttribute('aria-current', 'true');
        var n = document.createElement('strong'); n.textContent = c.name || c.email || 'Client';
        var s = document.createElement('span'); s.textContent = c.last;
        b.appendChild(n); b.appendChild(s);
        if (!c.last_from_pro) { var td = document.createElement('em'); td.className = 'todo'; td.textContent = 'À répondre'; b.appendChild(td); }
        b.addEventListener('click', function () {
          St.client = c.client_id; St.sig = ''; St.convSig = '';
          threadTitle.textContent = 'Conversation avec ' + (c.name || c.email || 'le client');
          msgText.disabled = false; msgSubmit.disabled = false; $('attach-btn').disabled = false;
          loadConvs(); loadThread();
        });
        li.appendChild(b); convList.appendChild(li);
      });
    } catch (e) {}
  }
  function refresh() {
    if (document.hidden || dash.hidden) return;
    if (St.user && St.user.isAdmin) loadConvs();
    loadThread();
  }
  function stopPoll() { if (St.timer) { clearInterval(St.timer); St.timer = null; } }
  function startPoll() { stopPoll(); St.timer = setInterval(refresh, 6000); }
  document.addEventListener('visibilitychange', function () { if (!document.hidden) refresh(); });

  function clearPhoto() {
    St.photo = null; fileInput.value = '';
    if (St.previewUrl) { URL.revokeObjectURL(St.previewUrl); St.previewUrl = null; }
    photoPrev.hidden = true; photoImg.src = BLANK;
  }
  function showAuth() {
    St.user = null; St.client = null; St.sig = ''; St.convSig = '';
    window.VP_PREFILL = undefined; document.title = BASE_TITLE;
    authBox.hidden = false; dash.hidden = true; recBox.hidden = true; stopPoll(); clearPhoto(); setTab('login');
  }
  function showRecovery() { authBox.hidden = true; dash.hidden = true; recBox.hidden = false; stopPoll(); }
  async function showDash(u) {
    St.user = u; St.client = u.isAdmin ? null : u.id; St.sig = ''; St.convSig = '';
    window.VP_PREFILL = u.isAdmin ? undefined : { name: u.name, email: u.email };
    authBox.hidden = true; recBox.hidden = true; dash.hidden = false;
    $('dash-hello').textContent = 'Bonjour, ' + u.name;
    $('quick').hidden = !!u.isAdmin; $('account-tools').hidden = !!u.isAdmin;
    inbox.hidden = !u.isAdmin; messaging.classList.toggle('has-inbox', !!u.isAdmin);
    say(msgStatus, ''); clearPhoto();
    if (u.isAdmin) {
      threadTitle.textContent = 'Messagerie : choisissez une conversation';
      msgText.disabled = true; msgSubmit.disabled = true; $('attach-btn').disabled = true;
      await loadConvs();
    } else {
      threadTitle.textContent = 'Messagerie avec votre plombier';
      msgText.disabled = false; msgSubmit.disabled = false; $('attach-btn').disabled = false;
    }
    await loadThread(); startPoll();
  }

  /* onglets */
  var tabLogin = $('tab-login'), tabSignup = $('tab-signup'), loginForm = $('login-form'), signupForm = $('signup-form');
  function setTab(which) {
    var login = which === 'login';
    tabLogin.setAttribute('aria-selected', login); tabSignup.setAttribute('aria-selected', !login);
    loginForm.hidden = !login; signupForm.hidden = login;
  }
  tabLogin.addEventListener('click', function () { setTab('login'); });
  tabSignup.addEventListener('click', function () { setTab('signup'); });

  loginForm.addEventListener('submit', async function (e) {
    e.preventDefault(); var st = $('login-status'), btn = $('login-submit');
    if (!loginForm.checkValidity()) { say(st, 'Saisissez votre e-mail et votre mot de passe.', 'err'); return; }
    btn.disabled = true; say(st, 'Connexion…');
    try {
      await Backend.signIn($('login-email').value.trim(), $('login-pass').value);
      var u = await Backend.session(); loginForm.reset(); say(st, '');
      if (u) await showDash(u);
    } catch (err) { say(st, frErr(err), 'err'); }
    btn.disabled = false;
  });
  $('forgot').addEventListener('click', async function () {
    var st = $('login-status'), em = $('login-email').value.trim();
    if (!em) { say(st, 'Saisissez d’abord votre e-mail ci-dessus.', 'err'); return; }
    try { await Backend.reset(em); say(st, 'Si un compte existe pour cet e-mail, un lien de réinitialisation vient d’être envoyé.', 'ok'); }
    catch (err) { say(st, frErr(err), 'err'); }
  });
  signupForm.addEventListener('submit', async function (e) {
    e.preventDefault(); var st = $('signup-status'), btn = $('signup-submit');
    if (!signupForm.checkValidity()) { say(st, 'Complétez tous les champs (mot de passe de 8 caractères minimum) et acceptez le traitement de vos données.', 'err'); signupForm.reportValidity(); return; }
    btn.disabled = true; say(st, 'Création du compte…');
    try {
      var r = await Backend.signUp($('signup-name').value.trim(), $('signup-email').value.trim(), $('signup-pass').value);
      signupForm.reset();
      if (r.needsConfirm) { say(st, 'Compte créé. Vérifiez votre boîte e-mail pour confirmer votre adresse, puis connectez-vous.', 'ok'); setTab('login'); }
      else { say(st, ''); var u = await Backend.session(); if (u) await showDash(u); }
    } catch (err) { say(st, frErr(err), 'err'); }
    btn.disabled = false;
  });
  $('recovery-form').addEventListener('submit', async function (e) {
    e.preventDefault(); var st = $('recovery-status'), a = $('rec-pass').value, b = $('rec-pass2').value;
    if (a.length < 8) { say(st, 'Mot de passe trop court (8 caractères minimum).', 'err'); return; }
    if (a !== b) { say(st, 'Les deux mots de passe ne correspondent pas.', 'err'); return; }
    try {
      await Backend.updatePassword(a); $('recovery-form').reset(); say(st, '');
      try { history.replaceState(null, '', location.pathname); } catch (x) {}
      var u = await Backend.session(); if (u) await showDash(u); else showAuth();
    } catch (err) { say(st, frErr(err), 'err'); }
  });
  $('logout').addEventListener('click', async function () { try { await Backend.signOut(); } catch (e) {} showAuth(); });
  $('delete-account').addEventListener('click', async function () {
    if (!St.user) return;
    if (!window.confirm('Supprimer définitivement votre compte et tous vos messages ? Cette action est irréversible.')) return;
    try {
      await Backend.deleteAccount(St.user.id); showAuth(); setTab('login');
      say($('login-status'), 'Votre compte et vos messages ont été supprimés.', 'ok');
    } catch (err) { say(msgStatus, 'Suppression impossible : ' + frErr(err), 'err'); }
  });

  /* photo à joindre */
  $('attach-btn').addEventListener('click', function () { fileInput.click(); });
  fileInput.addEventListener('change', function () {
    var f = fileInput.files && fileInput.files[0]; if (!f) return;
    if (!/^image\//.test(f.type)) { say(msgStatus, 'Choisissez une image (JPEG, PNG…).', 'err'); fileInput.value = ''; return; }
    if (f.size > 20 * 1024 * 1024) { say(msgStatus, 'Image trop lourde (20 Mo maximum).', 'err'); fileInput.value = ''; return; }
    if (St.previewUrl) URL.revokeObjectURL(St.previewUrl);
    St.photo = f; St.previewUrl = URL.createObjectURL(f); photoImg.src = St.previewUrl; photoPrev.hidden = false; say(msgStatus, '');
  });
  $('photo-remove').addEventListener('click', clearPhoto);

  /* envoi d'un message */
  msgForm.addEventListener('submit', async function (e) {
    e.preventDefault();
    var body = msgText.value.trim();
    if ((!body && !St.photo) || !St.client || !St.user) return;
    msgSubmit.disabled = true; msgSubmit.setAttribute('aria-busy', 'true');
    try {
      var blob = St.photo ? await compress(St.photo, Backend.photoOpts.max, Backend.photoOpts.q) : null;
      await Backend.send(St.client, body, !!St.user.isAdmin, St.user.id, blob);
      msgText.value = ''; clearPhoto(); say(msgStatus, '');
      await loadThread(); if (St.user.isAdmin) loadConvs();
    } catch (err) { say(msgStatus, 'Message non envoyé : ' + frErr(err), 'err'); }
    msgSubmit.disabled = false; msgSubmit.removeAttribute('aria-busy');
  });
  msgText.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); if (msgForm.requestSubmit) msgForm.requestSubmit(); }
  });

  /* ---------- Démarrage ---------- */
  function start() {
    $('demo-note').hidden = (Backend !== Demo);
    Backend.session().then(function (u) {
      if (cameFromRecovery && Backend === Sb) { showRecovery(); return; }
      if (u) showDash(u); else showAuth();
      if (cameFromEmail) { try { history.replaceState(null, '', location.pathname); } catch (e) {} }
    }).catch(showAuth);
    if (sb) {
      sb.auth.onAuthStateChange(function (ev) { if (ev === 'PASSWORD_RECOVERY') setTimeout(showRecovery, 0); });
    }
  }
  function unavailable() { authBox.hidden = true; $('unavailable').hidden = false; }
  if (hasSb) {
    loadScript(SUPABASE_CDN).then(function () {
      if (!window.supabase) throw new Error('no lib');
      sb = window.supabase.createClient(cfgSb.url, cfgSb.anonKey); Backend = Sb; start();
    }).catch(unavailable);
  } else { Backend = Demo; start(); }
})();
